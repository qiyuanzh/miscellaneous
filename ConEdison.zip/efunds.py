import pandas as pd
import numpy as np
import statsmodels.api as sm
from lazy import lazy
import datetime
import dateutil


class EFund (object):
    '''
    Class EFund takes Evestment fund monthly return data and its benchmark to calculate its alpha and tracking error.

    '''

    def __init__(self, EProdID, ret, benchmark= None):
        '''

        :param EProdID: str, Evestment Product ID
        :param ret: pd Series, fund ret series with time index
        :param benchmark: EFund obj, the benchmark of the fund
        '''

        self.EProdID= EProdID
        self.ret_raw= ret.copy()
        self.validStart= ret.first_valid_index()
        self.validEnd= ret.last_valid_index()
        self.validRet= self.ret_raw[ np.logical_and(self.ret_raw.index>= self.validStart,
                                                    self.ret_raw.index<= self.validEnd)]
        self.isMissing= any(np.isnan(self.validRet))

        if self.isMissing:
            self.validRet.fillna(0, inplace= True)

        self.isValidFund= len(self.validRet)>2

        self.value= np.nan
        self.DRisk= np.nan
        self.validAnnualRet= np.nan
        self.validAvgRet= np.nan
        self.volatility= np.nan
        self.SortinoRatio= np.nan
        self.benchmark= benchmark
        self.excessRet= None
        self.alpha= None
        self.te= None
        self.benchmarkIsValid= False
        self.benchmarkRet= None
        self.IR= None
        self.bmAnnualRet= None
        self.bmVolatility= None




        if self.isValidFund:
            self.value= self.__cumValue__(self.validRet)
            self.validAnnualRet= self.value.values[-1]**(12/ len(self.value.values))-1
            self.validAvgRet= self.validRet.mean()*12
            self.volatility= self.validRet.std()*np.sqrt(12)
            tmp= self.validRet.clip( upper= 0)
            self.DRisk= np.sqrt( (tmp*tmp).sum()/len(tmp) *12)
            self.SortinoRatio= self.validAnnualRet/ self.DRisk





            try:
                self.benchmarkRet= self.benchmark.validRet[np.logical_and(self.benchmark.validRet.index>= self.validStart, self.benchmark.validRet.index<= self.validEnd)]
                self.bmValue= self.__cumValue__(self.benchmarkRet)
                self.bmVolatility= self.benchmarkRet.std()* np.sqrt(12)
                self.bmAnnualRet= self.bmValue.values[-1]**(12/ len(self.bmValue.values))-1
                self.benchmarkIsValid= not(any(np.isnan(self.benchmarkRet)))
                self.excessRet= self.validRet- self.benchmarkRet
                self.alpha= self.validAnnualRet- self.bmAnnualRet
                self.te= self.excessRet.std()* np.sqrt(12)
                self.IR= self.alpha/ self.te
            except:
                pass

    @lazy
    def DDSeries (self):
        '''

        :return: pd Series, DD series
        '''
        tmp= self.value.rolling(window= len(self.value)+100, min_periods=1 ).max()
        return (self.value- tmp)/ tmp

    @lazy
    def MaxDD (self):
        '''

        :return: float, max DD
        '''
        return [self.DDSeries.idxmin(), self.DDSeries.min()]

    @lazy
    def RDDSeries(self):
        a= self.value/self.bmValue
        b= a.rolling(window= len(a)+100, min_periods=1).max()
        c= (a-b)/b
        return c

    @lazy
    def RMaxDD(self):
        return [self.RDDSeries.idxmin(), self.RDDSeries.min()]


    def hVaR(self, percentage):
        '''
        calculate the historical VaR based on available return series

        :param percentage: float, the percentage
        :return: [percentage, historical VaR]
        '''

        return [percentage, self.validRet.quantile(percentage)]


    def SharpeRatio(self, riskFree= 0):
        return (self.validAnnualRet- riskFree)/ self.volatility




    def __cumValue__ (self, ret):
        '''

        :param ret: pd Series, the valid pd Series with time index
        :return: pd Series, the cumulative value series (starting from 1)
        '''

        val= []
        curVal= 1
        for r in ret:
            curVal= curVal*(1+r)
            val.append(curVal)
        return pd.Series( data= val, index= ret.index, name= self.EProdID+'_value')

